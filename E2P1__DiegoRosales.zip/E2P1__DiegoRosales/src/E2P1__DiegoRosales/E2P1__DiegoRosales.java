
package E2P1__DiegoRosales;

public class E2P1__DiegoRosales {

    public static void main(String[] args) {
       Menu menuPrograma=new Menu(); 
        
        menuPrograma.setVisible(true); 
    }
    
}
